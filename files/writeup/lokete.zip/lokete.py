#!/usr/bin/python3

## Que locura el rosendo con las seeds eh
## Usando lo aprendido vamos a reirnos un poquito mÃ¡s, a ver si vamos aprendiendo a usar python q va tocando (no vale copiar el codigo que usasteis para rosendo)


### Se puede una pista a cambio de cafÃ© de la mÃ¡quina (tu verÃ¡s).

import os, sys, random
from Crypto.Util.number import bytes_to_long, isPrime, getPrime

seed_value = int(os.environ["SEED"]) # la seed soy yo
r = random
e = 0x10001
flag = os.environ["FLAG"].encode()

if __name__ == '__main__':
    
    r.seed(seed_value) 
    p = r.randint(2**128, 2**512)
    
    while not isPrime(p):
        p = r.randint(2**128, 2**512)
    
    q = getPrime(512)

    N = p * q

    print(f"N = {N}\ne = {e}\nC = {pow(bytes_to_long(flag), e, N)}")